
namespace AirbnbCamping.Services.Controllers
{
    public record UserProfileUpdate(string FullName, string ContactEmail, string? NewPassword);
}
