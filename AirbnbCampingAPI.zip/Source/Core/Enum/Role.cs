﻿namespace AirbnbCamping.Core.Enum;

public enum Role
{
    Owner,
    Client
}
